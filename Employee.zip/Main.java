public class Main {
  public static void main(String[] args) {

    Employee employee1 = new Employee("James Rodrigues", "HR Manager", 40000);
    Employee employee2 = new Employee("Lydia Clarett", "Software Engineer", 60000);
    System.out.println("\nEmployee Details:");
    employee1.printEmployeeDetails();
    employee2.printEmployeeDetails();

    employee1.raiseSalary(8);
    employee2.raiseSalary(12);

    System.out.println("\nAfter raising salary:");
    System.out.println("\n8% for 'James Rodrigues':");
    employee1.printEmployeeDetails();
    System.out.println("\n12% for 'Lydia Clarett':");
    employee2.printEmployeeDetails();
  }
}